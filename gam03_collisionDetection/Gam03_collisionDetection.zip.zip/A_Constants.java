
public final class A_Constants 
{
  public static final int WIDTH  = 1000;
  public static final int HEIGHT = 800;
}
