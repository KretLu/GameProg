
public class B_World extends Gam03_World 
{}
