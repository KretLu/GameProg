
// (c) Thorsten Hasbargen


final class A_GameObjectList extends java.util.ArrayList<A_GameObject> 
{ private static final long serialVersionUID = 1L;
}
